def Bye():
    print("Bye")

def Bye2():
    print("Bye2")